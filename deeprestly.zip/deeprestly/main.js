(function () {
  'use strict';

  // ---------- 1. NAVBAR scroll state ----------
  const nav = document.getElementById('nav');
  const onScroll = () => {
    if (window.scrollY > 40) nav.classList.add('nav-blur');
    else nav.classList.remove('nav-blur');
  };
  document.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  // ---------- 2. Reveal on scroll (Intersection Observer) ----------
  const reveals = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
    reveals.forEach(el => io.observe(el));
  } else {
    reveals.forEach(el => el.classList.add('in'));
  }

  // ---------- 3. Countdown timer (24h rolling, persisted) ----------
  const KEY = 'dr_countdown_end';
  const SHIFT = 24 * 60 * 60 * 1000;
  let endTime = parseInt(localStorage.getItem(KEY) || '0', 10);
  if (!endTime || endTime < Date.now()) {
    endTime = Date.now() + SHIFT;
    localStorage.setItem(KEY, String(endTime));
  }
  const cdH = document.getElementById('cd-h');
  const cdM = document.getElementById('cd-m');
  const cdS = document.getElementById('cd-s');
  const pad = n => n < 10 ? '0' + n : '' + n;

  function tick() {
    let diff = endTime - Date.now();
    if (diff <= 0) {
      endTime = Date.now() + SHIFT;
      localStorage.setItem(KEY, String(endTime));
      diff = SHIFT;
    }
    const h = Math.floor(diff / 3600000);
    const m = Math.floor((diff % 3600000) / 60000);
    const s = Math.floor((diff % 60000) / 1000);
    cdH.textContent = pad(h);
    cdM.textContent = pad(m);
    cdS.textContent = pad(s);
  }
  tick();
  setInterval(tick, 1000);

  // ---------- 4. Stock counter ----------
  const STOCK_KEY = 'dr_stock';
  const STOCK_TIME_KEY = 'dr_stock_last';
  const stockEl = document.getElementById('stock-count');
  const stockBar = document.getElementById('stock-bar');

  let stock = parseInt(localStorage.getItem(STOCK_KEY) || '47', 10);
  let lastTick = parseInt(localStorage.getItem(STOCK_TIME_KEY) || String(Date.now()), 10);

  // Catch-up: simulate decrement during time spent away
  const elapsed = Date.now() - lastTick;
  const minutes = Math.floor(elapsed / 60000);
  let decreaseBy = 0;
  for (let i = 0; i < minutes; i++) {
    // Random gate: roughly 1 every 4-7 min
    if (Math.random() < (1 / (4 + Math.random() * 3))) decreaseBy++;
  }
  stock = Math.max(12, stock - decreaseBy);
  localStorage.setItem(STOCK_KEY, String(stock));
  localStorage.setItem(STOCK_TIME_KEY, String(Date.now()));

  function renderStock() {
    if (!stockEl) return;
    stockEl.textContent = stock;
    if (stockBar) stockBar.style.width = Math.max(8, stock) + '%';
  }
  renderStock();

  function scheduleStockTick() {
    const delay = (4 + Math.random() * 3) * 60 * 1000; // 4–7 min
    setTimeout(() => {
      if (stock > 12) {
        stock -= 1;
        localStorage.setItem(STOCK_KEY, String(stock));
        localStorage.setItem(STOCK_TIME_KEY, String(Date.now()));
        renderStock();
      }
      scheduleStockTick();
    }, delay);
  }
  scheduleStockTick();

  // ---------- 5. FAQ accordion (one open at a time) ----------
  const faqs = document.querySelectorAll('details.faq');
  faqs.forEach(d => {
    d.addEventListener('toggle', () => {
      if (d.open) {
        faqs.forEach(other => { if (other !== d) other.open = false; });
      }
    });
  });

  // ---------- 6. Smooth scroll for in-page anchors (with sticky nav offset) ----------
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', (e) => {
      const id = a.getAttribute('href');
      if (id.length <= 1) return;
      const target = document.querySelector(id);
      if (!target) return;
      e.preventDefault();
      const navH = nav.offsetHeight || 72;
      const top = target.getBoundingClientRect().top + window.scrollY - navH + 4;
      window.scrollTo({ top, behavior: 'smooth' });
    });
  });

  // ---------- 7. Light "drag-to-scroll" on testimonials track for desktop fallback ----------
  const track = document.getElementById('reviews-track');
  if (track && window.matchMedia('(max-width: 1023px)').matches) {
    let isDown = false, startX = 0, scrollLeft = 0;
    track.addEventListener('pointerdown', (e) => {
      isDown = true;
      track.setPointerCapture(e.pointerId);
      startX = e.pageX - track.offsetLeft;
      scrollLeft = track.scrollLeft;
    });
    track.addEventListener('pointermove', (e) => {
      if (!isDown) return;
      const x = e.pageX - track.offsetLeft;
      track.scrollLeft = scrollLeft - (x - startX);
    });
    ['pointerup', 'pointercancel', 'pointerleave'].forEach(ev =>
      track.addEventListener(ev, () => { isDown = false; })
    );
  }

})();
